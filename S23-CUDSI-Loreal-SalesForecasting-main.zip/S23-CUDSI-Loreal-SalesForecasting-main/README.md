# S23-CUDSI-Loreal-SalesForecasting
This repository is used for Data Science Capstone (ENGI E4800), Spring 2023 at Columbia Engineering
